make clean
make
sudo make install
sudo ldconfig
